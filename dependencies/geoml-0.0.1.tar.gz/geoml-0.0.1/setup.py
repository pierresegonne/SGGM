import setuptools

# REQUIREMENTS = [i.strip() for i in open("requirements.txt").readlines()]

setuptools.setup(
    name="geoml",
    version="0.0.1",
    author="pierresegonne",
    author_email="pierre.segonne@protonmail.com",
    description="Private package for the geoml research repo.",
    url="https://bitbucket.org/soren_hauberg/geoml",
    packages=setuptools.find_packages(),
    classifiers=["Programming Language :: Python :: 3"],
    # Merge two approaches for requirements handling
    # install_requires=REQUIREMENTS,
)