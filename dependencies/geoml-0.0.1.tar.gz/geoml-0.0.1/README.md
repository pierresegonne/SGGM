## GeoML: practical algorithms for Geometric Machine Learning

The purpose of this package is to provide a set of elementary algorithms for computations on manifolds learned from finite noisy data. Each algorithm assume that the considered manifold model implement a specific set of interfaces.

For now, the repository is set up to be private within the group, but eventually we should share this with the world.

## Current state of affairs
The initial code contains a proposed way to structure a fairly generic set of geometric tools. The code currently contain two examples, which will be described here.

#### Example 1: geodesics on a sphere
The code for this example can be found within [examples/sphere_example.py](examples/sphere_example.py)

Let's step through the basics of the code. First we load the basic libraries needed along with matplotlib for plotting:

```python
#!/usr/bin/env python3
import torch
import numpy as np
from geoml import *
import matplotlib.pyplot as plt
```

Then we create an object describing the two-dimensional sphere embedded in three-dimensional Euclidean space. All computations will be done in spherical coordinates, so we can think of this sphere is a latent variable model, where the sphericial coordinates are latent variables, and points in R³ are like data points. This is just an analogy to show how one might choose to work with latent variable models.

```python
S = Sphere()
```

We then define two points in spherical coordinates, which we will seek to connect with a geodesic (shortest path).

```python
p0 = torch.tensor([0.1, 0.1]).reshape((1, -1))
p1 = torch.tensor([0.3, 0.7]).reshape((1, -1))
```

We then construct a cubic spline curve with fixed end-points corresponding to the chosen points. Alternatively, we could have created a simple discrete curve, but in general the spline is to be prefered.

```python
#C = DiscreteCurve(begin=p0, end=p1, num_nodes=8, requires_grad=True)
C = CubicSpline(begin=p0, end=p1, num_nodes=8, requires_grad=True)
```

We then optimize the curve energy measured on the spherical manifold with respect to the free parameters of the curve.

```python
geodesic_minimizing_energy(C, S)
```

Finally we plot the resulting curve in the latent space (i.e. in spherical coordinates).

```python
plt.show()
```
