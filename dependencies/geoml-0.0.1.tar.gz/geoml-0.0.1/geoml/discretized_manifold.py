#!/usr/bin/env python3
import torch
from geoml import *
import networkx as nx

class DiscretizedManifold:
    def __init__(self, model, grid, use_diagonals=False):
        """Approximate the latent space of a Manifold with a discrete grid.

        Inputs:
            model:  the Manifold to be approximated. This object should
                    implement the 'curve_length' function.

            grid:   a torch Tensor where the first dimension correspond
                    to the latent dimension of the manifold, and the
                    remaining are grid positions in a meshgrid format.
                    For example, a 2D manifold should be discretized by
                    a 2xNxM grid.
        """
        self.grid = grid
        self.G = nx.Graph()
        
        if grid.shape[0] != 2:
            raise Exception('Currently we only support 2D grids -- sorry!')

        # Add nodes to graph
        dim, xsize, ysize = grid.shape
        node_idx = lambda x, y: x*ysize + y
        self.G.add_nodes_from(range(xsize*ysize))
        #for x in range(xsize):
        #    for y in range(ysize):
        #        p = grid[:, x, y]
        #        self.G.add_node(node_idx(x, y))
        
        # add edges
        line = CubicSpline(begin=torch.zeros(1, dim), end=torch.ones(1, dim), num_nodes=2)
        t = torch.linspace(0, 1, 5)
        for x in range(xsize):
            for y in range(ysize):
                line.begin = grid[:, x, y].view(1, -1)
                n = node_idx(x, y)

                with torch.no_grad():
                    if x > 0:
                        line.end = grid[:, x-1, y].view(1, -1)
                        w = model.curve_length(line(t)).item()
                        self.G.add_edge(n, node_idx(x-1, y), weight=w)
                    if y > 0:
                        line.end = grid[:, x, y-1].view(1, -1)
                        w = model.curve_length(line(t)).item()
                        self.G.add_edge(n, node_idx(x, y-1), weight=w)
                    if x < xsize-1:
                        line.end = grid[:, x+1, y].view(1, -1)
                        w = model.curve_length(line(t)).item()
                        self.G.add_edge(n, node_idx(x+1, y), weight=w)
                    if y < ysize-1:
                        line.end = grid[:, x, y+1].view(1, -1)
                        w = model.curve_length(line(t)).item()
                        self.G.add_edge(n, node_idx(x, y+1), weight=w)
                    if use_diagonals and x > 0 and y > 0:
                        line.end = grid[:, x-1, y-1].view(1, -1)
                        w = model.curve_length(line(t)).item()
                        self.G.add_edge(n, node_idx(x-1, y-1), weight=w)
                    if use_diagonals and x < xsize-1 and y > 0:
                        line.end = grid[:, x+1, y-1].view(1, -1)
                        w = model.curve_length(line(t)).item()
                        self.G.add_edge(n, node_idx(x+1, y-1), weight=w)

    def grid_point(self, p):
        """Return the index of the nearest grid point.

        Input:
            p:      a torch Tensor corresponding to a latent point.
        
        Output:
            idx:    an integer correponding to the node index of
                    the nearest point on the grid.
        """
        return (self.grid.view(self.grid.shape[0], -1) - p.view(-1, 1)).pow(2).sum(dim=0).argmin().item()

    def shortest_path(self, p1, p2):
        """Compute the shortest path on the discretized manifold.

        Inputs:
            p1:     a torch Tensor corresponding to one latent point.

            p2:     a torch Tensor corresponding to another latent point.
        
        Outputs:
            curve:  a DiscreteCurve forming the shortest path from p1 to p2.

            dist:   a scalar indicating the length of the shortest curve.
        """
        idx1 = self.grid_point(p1)
        idx2 = self.grid_point(p2)
        path = nx.shortest_path(self.G, source=idx1, target=idx2, weight='weight') # list with N elements
        coordinates = self.grid.view(self.grid.shape[0], -1)[:, path] # (dim)xN
        N = len(path)
        curve = DiscreteCurve(begin=coordinates[:, 0], end=coordinates[:, -1], num_nodes=N)
        with torch.no_grad():
            curve.parameters[:, :] = coordinates[:, 1:-1].t()
        dist = 0
        for i in range(N-1):
            dist += self.G.edges[path[i], path[i+1]]['weight']
        return curve, dist

    def connecting_geodesic(self, p1, p2, curve=None): 
        """Compute the shortest path on the discretized manifold and fit
        a smooth curve to the resulting discrete curve.

        Inputs:
            p1:     a torch Tensor corresponding to one latent point.

            p2:     a torch Tensor corresponding to another latent point.
        
        Optional input:
            curve:  a curve that should be fitted to the discrete graph
                    geodesic. By default this is None and a CubicSpline
                    with default paramaters will be constructed.
        
        Outputs:
            curve:  a smooth curve forming the shortest path from p1 to p2.
                    By default the curve is a CubicSpline with its default
                    parameters; this can be changed through the optional
                    curve input.
        """
        device = p1.device
        idx1 = self.grid_point(p1)
        idx2 = self.grid_point(p2)
        path = nx.shortest_path(self.G, source=idx1, target=idx2, weight='weight') # list with N elements
        weights = [self.G.edges[path[k], path[k+1]]['weight'] for k in range(len(path)-1)]
        coordinates = (self.grid.view(self.grid.shape[0], -1)[:, path[1:-1]]).t() # Nx(dim)
        t = torch.tensor(weights[:-1], device=device).cumsum(dim=0) / sum(weights)
        
        if curve is None:
            curve = CubicSpline(p1, p2)
        else:
            curve.begin = p1
            curve.end = p2

        curve.fit(t, coordinates)

        return curve


class DiscretizedMetric(Manifold):
    def __init__(self):
        self.grid = []
        self.grid_size = []
        self.G = nx.Graph()
        self.__metric__ = torch.Tensor()
        self._diagonal_metric = False
        self._alpha = torch.Tensor()

    def fit(self, model, grid, use_diagonals=True, interpolation_noise=0.0):
        """Approximate the latent space of a Manifold with a discrete grid.

        Inputs:
            model:  the Manifold to be approximated. This object should
                    implement the 'curve_length' function.

            grid:   a list of linspaces, e.g. a 2D latent space would be discretized by
                    [torch.linspace(-3, 3, 50), torch.linspace(-3, 3, 50)]
        """
        self.grid = grid
        self.grid_size = [g.numel() for g in grid]
        self.G = nx.Graph()

        # Currently things only work for 2D manifolds

        # Add nodes to graph
        dim = len(grid)
        xsize = grid[0].numel()
        ysize = grid[1].numel()
        node_idx = lambda x, y: x*ysize + y
        self.G.add_nodes_from(range(xsize*ysize))
        
        # add edges to graph
        # weights are computed as Riemannian length of straight lines connecting nodes
        line = CubicSpline(begin=torch.zeros(1, dim), end=torch.ones(1, dim), num_nodes=2)
        t = torch.linspace(0, 1, 5)
        for x in range(xsize):
            for y in range(ysize):
                line.begin = torch.tensor([grid[0][x], grid[1][y]]).view(1, -1)
                n = node_idx(x, y)

                with torch.no_grad():
                    if x > 0:
                        line.end = torch.tensor([grid[0][x-1], grid[1][y]]).view(1, -1)
                        w = model.curve_length(line(t)).item()
                        self.G.add_edge(n, node_idx(x-1, y), weight=w)
                    if y > 0:
                        line.end = torch.tensor([grid[0][x], grid[1][y-1]]).view(1, -1) #grid[:, x, y-1].view(1, -1)
                        w = model.curve_length(line(t)).item()
                        self.G.add_edge(n, node_idx(x, y-1), weight=w)
                    if x < xsize-1:
                        line.end = torch.tensor([grid[0][x+1], grid[1][y]]).view(1, -1) # grid[:, x+1, y].view(1, -1)
                        w = model.curve_length(line(t)).item()
                        self.G.add_edge(n, node_idx(x+1, y), weight=w)
                    if y < ysize-1:
                        line.end = torch.tensor([grid[0][x], grid[1][y+1]]).view(1, -1) # grid[:, x, y+1].view(1, -1)
                        w = model.curve_length(line(t)).item()
                        self.G.add_edge(n, node_idx(x, y+1), weight=w)
                    if use_diagonals and x > 0 and y > 0:
                        line.end = torch.tensor([grid[0][x-1], grid[1][y-1]]).view(1, -1) # grid[:, x-1, y-1].view(1, -1)
                        w = model.curve_length(line(t)).item()
                        self.G.add_edge(n, node_idx(x-1, y-1), weight=w)
                    if use_diagonals and x < xsize-1 and y > 0:
                        line.end = torch.tensor([grid[0][x+1], grid[1][y-1]]).view(1, -1) # grid[:, x+1, y-1].view(1, -1)
                        w = model.curve_length(line(t)).item()
                        self.G.add_edge(n, node_idx(x+1, y-1), weight=w)

        # Evaluate metric at grid
        Mlist = []
        with torch.no_grad():
            for x in range(xsize):
                for y in range(ysize):
                    p = torch.tensor([self.grid[0][x], self.grid[1][y]])
                    Mlist.append(model.metric(p)) # 1x(d)x(d) or 1x(d)
        M = torch.cat(Mlist, dim=0) # (big)x(d)x(d) or (big)x(d)
        self._diagonal_metric = M.dim() == 2
        d = M.shape[-1]
        if self._diagonal_metric:
            self.__metric__ = M.view([*self.grid_size, d]) # e.g. (xsize)x(ysize)x(d)
        else:
            self.__metric__ = M.view([*self.grid_size, d, d]) # e.g. (xsize)x(ysize)x(d)x(d)
        
        # Compute interpolation weights. We use the mean function of a GP regressor from noisefree data
        # XXX: Check that meshgrid orders point the same way as we loop -- otherwise this will be rubish!
        mesh = torch.meshgrid(*self.grid)
        grid_points =  torch.cat([m.unsqueeze(-1) for m in mesh], dim=-1) # e.g. 100x100x2 a 2D grid with 100 points in each dim
        K = self._kernel(grid_points.view(-1, len(self.grid))) # (big)x(big)
        if interpolation_noise > 0.0:
            K += interpolation_noise * torch.eye(K.shape[0])
        num_grid = K.shape[0]
        self._alpha, _ = torch.solve(self.__metric__.view(num_grid, -1), K) # (num_grid)x(d²) or (num_grid)x(d)

    def set(self, metric, grid, use_diagonals=True):
        """
        be able to set metric directly from a pre-evaluated grid
        """
        pass

    def metric(self, points):
        """
        Return the metric tensor at a specified set of points.

        Input:
            points:     a Nx(d) torch Tensor representing a set of
                        points where the metric tensor is to be
                        computed.

        Output:
            M:          a Nx(d)x(d) or Nx(d) torch Tensor representing
                        the metric tensor at the given points.
                        If M is Nx(d)x(d) then M[i] is a (d)x(d) symmetric
                        positive definite matrix. If M is Nx(d) then M[i]
                        is to be interpreted as the diagonal elements of
                        a (d)x(d) diagonal matrix.
        """
        # XXX: We should also support returning the derivative of the metric! (for ODEs; see local_PCA)
        K = self._kernel(points) # Nx(num_grid)
        M = K.mm(self._alpha) # Nx(d²) or Nx(d)
        if not self._diagonal_metric:
            d = len(grid)
            M = M.view(-1, d, d)
        return M

    def grid_dist2(self, p):
        """Return the squared Euclidean distance from a set of points to the grid.

        Input:
            p:      a Nx(d) torch Tensor corresponding to N latent points.

        Output:
            dist2:  a NxM torch Tensor containing all Euclidean distances
                    to the M grid points.
        """

        dist2 = torch.zeros(p.shape[0], self.G.number_of_nodes())
        mesh = torch.meshgrid(*self.grid)
        for mesh_dim, dim in zip(mesh, range(len(self.grid))):
            dist2 += (p[:, dim].view(-1, 1) - mesh_dim.reshape(1, -1))**2
        return dist2

    def _kernel(self, p):
        lengthscales = [(g[1]-g[0])**2 for g in self.grid]

        dist2 = torch.zeros(p.shape[0], self.G.number_of_nodes())
        mesh = torch.meshgrid(*self.grid)
        for mesh_dim, dim in zip(mesh, range(len(self.grid))):
            dist2 += (p[:, dim].view(-1, 1) - mesh_dim.reshape(1, -1))**2/lengthscales[dim]

        return torch.exp(-dist2)

    def grid_point(self, p):
        """Return the index of the nearest grid point.

        Input:
            p:      a torch Tensor corresponding to a latent point.
        
        Output:
            idx:    an integer correponding to the node index of
                    the nearest point on the grid.
        """
        return self.grid_dist2(p).argmin().item()

    def shortest_path(self, p1, p2):
        """Compute the shortest path on the discretized manifold.

        Inputs:
            p1:     a torch Tensor corresponding to one latent point.

            p2:     a torch Tensor corresponding to another latent point.
        
        Outputs:
            curve:  a DiscreteCurve forming the shortest path from p1 to p2.

            dist:   a scalar indicating the length of the shortest curve.
        """
        idx1 = self.grid_point(p1)
        idx2 = self.grid_point(p2)
        path = nx.shortest_path(self.G, source=idx1, target=idx2, weight='weight') # list with N elements
        #coordinates = self.grid.view(self.grid.shape[0], -1)[:, path] # (dim)xN
        mesh = torch.meshgrid(*self.grid)
        raw_coordinates = [m.flatten()[path].view(1, -1) for m in mesh]
        coordinates = torch.cat(raw_coordinates, dim=0) # (dim)xN
        N = len(path)
        curve = DiscreteCurve(begin=coordinates[:, 0], end=coordinates[:, -1], num_nodes=N)
        with torch.no_grad():
            curve.parameters[:, :] = coordinates[:, 1:-1].t()
        dist = 0
        for i in range(N-1):
            dist += self.G.edges[path[i], path[i+1]]['weight']
        return curve, dist

    def connecting_geodesic(self, p1, p2, curve=None): 
        """Compute the shortest path on the discretized manifold and fit
        a smooth curve to the resulting discrete curve.

        Inputs:
            p1:     a torch Tensor corresponding to one latent point.

            p2:     a torch Tensor corresponding to another latent point.
        
        Optional input:
            curve:  a curve that should be fitted to the discrete graph
                    geodesic. By default this is None and a CubicSpline
                    with default paramaters will be constructed.
        
        Outputs:
            curve:  a smooth curve forming the shortest path from p1 to p2.
                    By default the curve is a CubicSpline with its default
                    parameters; this can be changed through the optional
                    curve input.
        """
        device = p1.device
        idx1 = self.grid_point(p1)
        idx2 = self.grid_point(p2)
        path = nx.shortest_path(self.G, source=idx1, target=idx2, weight='weight') # list with N elements
        weights = [self.G.edges[path[k], path[k+1]]['weight'] for k in range(len(path)-1)]
        mesh = torch.meshgrid(*self.grid)
        raw_coordinates = [m.flatten()[path[1:-1]].view(-1, 1) for m in mesh]
        coordinates = torch.cat(raw_coordinates, dim=1) # Nx(dim)
        t = torch.tensor(weights[:-1], device=device).cumsum(dim=0) / sum(weights)
        
        if curve is None:
            curve = CubicSpline(p1, p2)
        else:
            curve.begin = p1
            curve.end = p2

        curve.fit(t, coordinates)

        return curve
