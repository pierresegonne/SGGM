#!/usr/bin/env python3
import torch


class BasicCurve:
    def plot(self, t0=0, t1=1, N=100):
        with torch.no_grad():
            import torchplot as plt

            t = torch.linspace(t0, t1, N, dtype=self.begin.dtype, device=self.device)
            points = self(t)  # NxD or BxNxD
            if len(points.shape) == 2:
                points.unsqueeze_(0)  # 1xNxD
            if points.shape[-1] == 1:
                for b in range(points.shape[0]):
                    plt.plot(t, points[b])
            elif points.shape[-1] == 2:
                for b in range(points.shape[0]):
                    plt.plot(points[b, :, 0], points[b, :, 1], "-")
            else:
                print("BasicCurve.plot: plotting is only supported in 1D and 2D")

    def euclidean_length(self, t0=0, t1=1, N=100):
        t = torch.linspace(t0, t1, N)
        points = self(t)  # NxD or BxNxD
        is_batched = points.dim() > 2
        if not is_batched:
            points = points.unsqueeze(0)
        delta = points[:, 1:] - points[:, :-1]  # Bx(N-1)xD
        energies = (delta ** 2).sum(dim=2)  # Bx(N-1)
        lengths = energies.sqrt().sum(dim=1)  # B
        return lengths


class DiscreteCurve(BasicCurve):
    def __init__(self, begin, end, num_nodes=5, device=None, requires_grad=True):
        self.device = begin.device if device is None else device
        self.t = torch.linspace(0, 1, num_nodes, dtype=begin.dtype)[1:-1].view(
            (-1, 1)
        )  # (num_nodes-2)x1
        self.num_nodes = num_nodes
        self.begin = begin.view((1, -1))
        self.end = end.view((1, -1))
        self.parameters = (
            self.t.mm(self.end) + (1 - self.t).mm(self.begin)
        ).requires_grad_()  # (num_nodes-2)xD

    def __call__(self, t):
        tflat = t.flatten()
        start_nodes = torch.cat((self.begin, self.parameters))  # (num_edges)xD
        end_nodes = torch.cat((self.parameters, self.end))  # (num_edges)xD
        num_edges, D = start_nodes.shape
        t0 = torch.cat(
            (
                torch.zeros(1, 1, dtype=self.t.dtype),
                self.t.view((-1, 1)),
                torch.ones(1, 1, dtype=self.t.dtype),
            )
        )
        a = (end_nodes - start_nodes) / (t0[1:] - t0[:-1]).expand(
            -1, D
        )  # (num_edges)xD
        b = start_nodes - a * t0[:-1].expand(-1, D)  # (num_edges)xD

        # idx = torch.tensor([torch.nonzero(tflat[i] <= t0.flatten()[1:])[0] for i in range(t.numel())]) # use this if nodes are not equi-distant
        idx = (
            torch.floor(t.flatten() * num_edges).clamp(min=0, max=num_edges - 1).long()
        )  # use this if nodes are equi-distant
        tt = t.view((-1, 1)).expand(-1, D)
        result = a[idx] * tt + b[idx]  # NxD
        return result

    # def reparam(self):
    #    with torch.no_grad():
    #        start_nodes = torch.cat((self.begin, self.parameters))  # (num_edges)xD
    #        end_nodes   = torch.cat((self.parameters, self.end))    # (num_edges)xD
    #        edge_len = (end_nodes - start_nodes).norm(dim=1) # (num_edges)
    #        cs_len =  edge_len.cumsum(dim=0) # (num_edges)
    #        cs_len /= cs_len[-1]
    #
    #        L = DiscreteCurve(torch.zeros(1), torch.ones(1), num_nodes=self.num_nodes, requires_grad=False)
    #        L.t = cs_len[:-1].view((-1, 1))
    #        new_t = L(torch.linspace(0, 1, self.num_nodes)[1:-1])
    #        self.parameters[:] = self(new_t)


class QuadraticCurve(BasicCurve):
    def __init__(self, begin, end, device=None, requires_grad=True):
        self.device = begin.device if device is None else device

        # begin # D or 1xD or BxD
        if len(begin.shape) == 1 or begin.shape[0] == 1:
            self.begin = begin.detach().view((1, -1))  # 1xD
        else:
            self.begin = begin.detach()  # BxD
        if len(end.shape) == 1 or end.shape[0] == 1:
            self.end = end.detach().view((1, -1))  # 1xD
        else:
            self.end = end.detach()  # BxD

        self.delta = end - begin  # BxD
        self.parameters = torch.zeros(
            self.delta.shape,
            dtype=begin.dtype,
            device=self.device,
            requires_grad=requires_grad,
        )  # BxD
        self.c = begin  # BxD

    def __call__(self, t):
        b = self.delta - self.parameters  # BxD
        tt = t.view(1, -1, 1).repeat(b.shape[0], 1, 1)  # Bx1|t|x1
        tt2 = tt ** 2  # Bx|t|x1
        return (
            tt2.bmm(self.parameters.unsqueeze(1))
            + tt.bmm(b.unsqueeze(1))
            + self.c.unsqueeze(1)
        )  # Bx|t|xD


class CubicSpline(BasicCurve):
    # Compute cubic spline basis with end-points (0, 0) and (1, 0)
    def compute_basis(self, num_edges, device=None):
        with torch.no_grad():
            # set up constraints
            t = torch.linspace(0, 1, num_edges + 1, dtype=self.begin.dtype)[1:-1]

            end_points = torch.zeros(
                2, 4 * num_edges, dtype=self.begin.dtype, device=device
            )
            end_points[0, 0] = 1.0
            end_points[1, -4:] = 1.0

            zeroth = torch.zeros(
                num_edges - 1, 4 * num_edges, dtype=self.begin.dtype, device=device
            )
            for i in range(num_edges - 1):
                si = 4 * i  # start index
                fill = torch.tensor(
                    [1.0, t[i], t[i] ** 2, t[i] ** 3], dtype=self.begin.dtype
                )
                zeroth[i, si : (si + 4)] = fill
                zeroth[i, (si + 4) : (si + 8)] = -fill

            first = torch.zeros(
                num_edges - 1, 4 * num_edges, dtype=self.begin.dtype, device=device
            )
            for i in range(num_edges - 1):
                si = 4 * i  # start index
                fill = torch.tensor(
                    [0.0, 1.0, 2.0 * t[i], 3.0 * t[i] ** 2], dtype=self.begin.dtype
                )
                first[i, si : (si + 4)] = fill
                first[i, (si + 4) : (si + 8)] = -fill

            second = torch.zeros(
                num_edges - 1, 4 * num_edges, dtype=self.begin.dtype, device=device
            )
            for i in range(num_edges - 1):
                si = 4 * i  # start index
                fill = torch.tensor([0.0, 0.0, 6.0 * t[i], 2.0], dtype=self.begin.dtype)
                second[i, si : (si + 4)] = fill
                second[i, (si + 4) : (si + 8)] = -fill

            constraints = torch.cat((end_points, zeroth, first, second))
            self.constraints = constraints

            ## Compute null space, which forms our basis
            _, S, V = torch.svd(constraints, some=False)
            basis = V[:, S.numel() :]  # (num_coeffs)x(intr_dim)

            return basis

    def __init__(
        self,
        begin,
        end,
        num_nodes=5,
        basis=None,
        device=None,
        requires_grad=True,
        parameters=None,
    ):
        self.device = begin.device if device is None else device
        # begin # D or 1xD or BxD
        if len(begin.shape) == 1 or begin.shape[0] == 1:
            self.begin = begin.detach().view((1, -1))  # 1xD
        else:
            self.begin = begin.detach()  # BxD
        if len(end.shape) == 1 or end.shape[0] == 1:
            self.end = end.detach().view((1, -1))  # 1xD
        else:
            self.end = end.detach()  # BxD
        self.num_nodes = num_nodes
        if basis is None:
            self.basis = self.compute_basis(
                num_edges=num_nodes - 1, device=self.device
            )  # (num_coeffs)x(intr_dim)
        else:
            self.basis = basis
        if parameters is None:
            self.parameters = torch.zeros(
                self.begin.shape[0],
                self.basis.shape[1],
                self.begin.shape[1],
                dtype=self.begin.dtype,
                device=self.device,
                requires_grad=requires_grad,
            )  # Bx(intr_dim)xD
        else:
            if parameters.ndim == 2:
                self.parameters = parameters.unsqueeze(0)
            else:
                self.parameters = parameters

    def __getitem__(self, indices):
        C = CubicSpline(
            begin=self.begin[indices],
            end=self.end[indices],
            num_nodes=self.num_nodes,
            basis=self.basis,
            device=self.device,
            parameters=self.parameters[indices],
        )
        return C

    def __setitem__(self, indices, curves):
        self.parameters[indices] = curves.parameters

    def __ppeval__(self, t, coeffs):
        # each row of coeffs should be of the form c0, c1, c2, ... representing polynomials
        # of the form c0 + c1*t + c2*t^2 + ...
        # coeffs: Bx(num_edges)x(degree)xD
        B, num_edges, degree, D = coeffs.shape
        idx = torch.floor(t * num_edges).clamp(min=0, max=num_edges - 1).long()  # Bx|t|
        power = (
            torch.arange(0.0, degree, dtype=t.dtype, device=self.device)
            .view(1, 1, -1)
            .expand(B, -1, -1)
        )  # Bx1x(degree)
        tpow = t.view(B, -1, 1).pow(power)  # Bx|t|x(degree)
        coeffs_idx = torch.cat(
            [coeffs[k, idx[k]].unsqueeze(0) for k in range(B)]
        )  # Bx|t|x(degree)xD
        retval = torch.sum(
            tpow.unsqueeze(-1).expand(-1, -1, -1, D) * coeffs_idx, dim=2
        )  # Bx|t|xD
        return retval

    def get_coeffs(self):
        coeffs = (
            self.basis.unsqueeze(0)
            .expand(self.parameters.shape[0], -1, -1)
            .bmm(self.parameters)
        )  # Bx(num_coeffs)xD
        B, num_coeffs, D = coeffs.shape
        degree = 4
        num_edges = num_coeffs // degree
        coeffs = coeffs.view(B, num_edges, degree, D)  # Bx(num_edges)x4xD
        return coeffs

    def __eval_straight_line__(self, t):
        B, T = t.shape
        tt = t.view(B, T, 1)  # Bx|t|x1
        retval = (1 - tt).bmm(self.begin.unsqueeze(1)) + tt.bmm(
            self.end.unsqueeze(1)
        )  # Bx|t|xD
        return retval

    def __call__(self, t):
        coeffs = self.get_coeffs()  # Bx(num_edges)x4xD
        no_batch = t.dim() == 1
        if no_batch:
            t = t.expand(coeffs.shape[0], -1)  # Bx|t|
        retval = self.__ppeval__(t, coeffs)  # Bx|t|xD
        # tt = t.view((-1, 1)).unsqueeze(0).expand(retval.shape[0], -1, -1) # Bx|t|x1
        # retval += (1-tt).bmm(self.begin.unsqueeze(1)) + tt.bmm(self.end.unsqueeze(1)) # Bx|t|xD
        retval += self.__eval_straight_line__(t)
        if no_batch and retval.shape[0] == 1:
            retval.squeeze_(0)  # |t|xD
        return retval

    def deriv(self, t=None):
        """
        Return the derivative of the curve at a given time point.
        """
        coeffs = self.get_coeffs()  # Bx(num_edges)x4xD
        B, num_edges, degree, D = coeffs.shape
        dcoeffs = coeffs[:, :, 1:, :] * torch.arange(
            1.0, degree, dtype=coeffs.dtype, device=self.device
        ).view(1, 1, -1, 1).expand(
            B, num_edges, -1, D
        )  # Bx(num_edges)x3xD
        delta = self.end - self.begin  # BxD
        if t is None:
            # construct the derivative spline
            print(
                "WARNING: Construction of spline derivative objects is currently broken!"
            )
            Z = torch.zeros(B, num_edges, 1, D)  # Bx(num_edges)x1xD
            new_coeffs = torch.cat((dcoeffs, Z), dim=2)  # Bx(num_edges)x4xD
            print("***", new_coeffs[0, 0, :, 0])
            retval = CubicSpline(begin=delta, end=delta, num_nodes=self.num_nodes)
            retval.parameters = (
                retval.basis.t().expand(B, -1, -1).bmm(new_coeffs.view(B, -1, D))
            )  # Bx|parameters|xD
        else:
            if t.dim() == 1:
                t = t.expand(coeffs.shape[0], -1)  # Bx|t|
            # evaluate the derivative spline
            retval = self.__ppeval__(t, dcoeffs)  # Bx|t|xD
            # tt = t.view((-1, 1)) # |t|x1
            retval += delta.unsqueeze(1)
        return retval

        # d + c*t + b*t^2 + a*t^3   =>
        # c + 2*b*t + 3*a*t^2

    def fit(self, t, x):
        """Fit the curve to the points by minimizing |x - c(t)|²

        Inputs:
            t:  a torch tensor with N elements showing where to evaluate the curve.
            x:  a torch tensor of size NxD containing the requested
                values the curve should take at time t.
        """

        # XXX: Rewrite this to use the closed-form solution
        # Below is broken attempt at a closed-form solution
        # # subtract the straight line from x
        # if x.dim() == 2: # batch of one
        #     xx = x.unsqueeze(0) - self.__eval_straight_line__(t) # BxNxD
        # else:
        #     xx = x - self.__eval_straight_line__(t) # BxNxD

        # coeffs = self.get_coeffs()
        # B, num_edges, degree, D = coeffs.shape
        # if B != 1:
        #     print('Currently fit is not batched')
        #     return
        # xx.squeeze_(0) # NxD --- XXX: Make this go away
        # idx = torch.floor(t.flatten() * num_edges).clamp(min=0, max=num_edges-1).long() # |t|
        # tpow = t.view(-1, 1).pow(torch.arange(0.0, degree, dtype=t.dtype, device=self.device).view(1, -1)) # |t|x(degree)
        # new_coeffs_list = []
        # for edge in range(num_edges):
        #     R = tpow[idx==edge].pinverse() # (degree)x(obs_in_edge)
        #     xe = xx[idx==edge] # (obs_in_edge)xD --- XXX: This one should eventually be batched
        #     pol = R.mm(xe) # (degree)xD
        #     new_coeffs_list.append(pol)
        # new_coeffs = torch.cat(new_coeffs_list, dim=0) # (num_edges*degree)xD --- XXX: change dim for batching
        # self.parameters = self.basis.t().mm(new_coeffs).unsqueeze(0) # 1x(num_param)xD --- XXX: Make sure this one has requires_grad
        # return new_coeffs_list

        # using a second order method on a linear problem should imply
        # that we get to the optimum in few iterations (ideally 1).
        opt = torch.optim.LBFGS([self.parameters])
        loss = torch.nn.MSELoss()

        def closure():
            opt.zero_grad()
            L = loss(self(t), x)
            L.backward()
            return L

        for _ in range(50):
            opt.step(closure=closure)
            # print(torch.max(torch.abs(self.parameters.grad.norm())))
            if torch.max(torch.abs(self.parameters.grad)) < 1e-6:
                break

    def constant_speed(self, metric=None, t=None):
        """
        Reparametrize the curve to have constant speed.

        Optional input:
            metric:     the Manifold under which the curve should have constant speed.
                        If None then the Euclidean metric is applied.
                        Default: None.

        Note: It is not possible to back-propagate through this function.
        Note: This function does currently not support batching.
        """
        with torch.no_grad():
            if t is None:
                t = torch.linspace(0, 1, 100)  # N
            Ct = self(t)  # NxD or BxNxD
            if Ct.dim() == 2:
                Ct.unsqueeze_(0)  # BxNxD
            B, N, D = Ct.shape
            delta = Ct[:, 1:] - Ct[:, :-1]  # Bx(N-1)xD
            if metric is None:
                local_len = delta.norm(dim=2)  # Bx(N-1)
            else:
                local_len = (
                    metric.inner(
                        Ct[:, :-1].reshape(-1, D), delta.view(-1, D), delta.view(-1, D)
                    )
                    .view(B, N - 1)
                    .sqrt()
                )  # Bx(N-1)
            cs = local_len.cumsum(dim=1)  # Bx(N-1)
            new_t = torch.cat(
                (torch.zeros(B, 1), cs / cs[:, -1].unsqueeze(1)), dim=1
            )  # BxN
            with torch.enable_grad():
                self.fit(new_t, Ct)
            return new_t, Ct
